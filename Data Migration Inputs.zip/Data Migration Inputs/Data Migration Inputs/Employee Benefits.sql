CREATE OR REPLACE PROCEDURE employee_data IS
  -- Declare variables
  v_employee_id        NUMBER(10, 2);
  v_department_id      NUMBER(10, 2);
  v_salary             NUMBER(10, 2);
  v_department_name    VARCHAR2(100);
  v_bonus              NUMBER(10, 2);
  v_job_id             NUMBER(10, 2);
  v_manager_id         NUMBER(10, 2);
  v_hire_date          DATE;
  v_years_of_service   NUMBER(2);
  v_performance_rating VARCHAR2(100);
  v_total_compensation NUMBER(10, 2);
  v_bonus_notification VARCHAR2(100);

  CURSOR emp_cursor IS
    SELECT employee_id, department_id, salary, job_id, manager_id, hire_date, performance_rating
    FROM employees
    WHERE salary > 5000;
	
  -- Define a batch size for commit intervals
  BATCH_SIZE CONSTANT NUMBER := 100;
  batch_count NUMBER := 0;

BEGIN
  -- Initialize bonus calculation
  v_bonus := 0;

  -- Loop through employees with salary > 5000
  FOR emp_rec IN emp_cursor LOOP
    v_employee_id := emp_rec.employee_id;
    v_department_id := emp_rec.department_id;
    v_salary := emp_rec.salary;
    v_job_id := emp_rec.job_id;
    v_manager_id := emp_rec.manager_id;
    v_hire_date := emp_rec.hire_date;
    v_performance_rating := emp_rec.performance_rating;

    -- Calculate years of service
    v_years_of_service := TRUNC(MONTHS_BETWEEN(SYSDATE, v_hire_date) / 12);

    -- Calculate bonus based on salary and performance rating
    IF v_salary BETWEEN 5001 AND 10000 THEN
      v_bonus := v_salary * 0.10;
    ELSIF v_salary BETWEEN 10001 AND 20000 THEN
      v_bonus := v_salary * 0.15;
    ELSE
      v_bonus := v_salary * 0.20;
    END IF;

  END LOOP; -- emp_cursor

  -- Final commit if there are remaining uncommitted records
  IF batch_count > 0 THEN
    COMMIT;
  END IF;

EXCEPTION
  WHEN OTHERS THEN
    -- Handle any exceptions
    ROLLBACK;
    DBMS_OUTPUT.PUT_LINE('Error occurred: ' || SQLERRM);
END employee_data;