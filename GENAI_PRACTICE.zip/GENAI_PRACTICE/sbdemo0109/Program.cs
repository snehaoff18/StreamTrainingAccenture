﻿using OpenAI_API;
using System;
using System.Threading.Tasks;
class Program
{
    static async Task Main(string[] args)
    {
        var api=new OpenAIAPI("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");
        var request= new OpenAI_API.Images.ImageGenerationRequest
        {
            Prompt=" a frog on a mushroom"
        };
        var response = await api.ImageGenerations.CreateImageAsync(request);
        Console.WriteLine("Image URL: {0}", response.Data[0].Url);
    }
}
