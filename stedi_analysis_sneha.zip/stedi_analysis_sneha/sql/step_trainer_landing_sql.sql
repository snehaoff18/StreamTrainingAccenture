CREATE EXTERNAL TABLE `step_trainer_landing`(
`sensorreadingtime` bigint COMMENT 'from deserializer',
`serialnumber` string COMMENT 'from deserializer',
`distancefromobject` int COMMENT 'from deserializer')
ROW FORMAT SERDE
'org.openx.data.jsonserde.JsonSerDe'
STORED AS INPUTFORMAT
'org.apache.hadoop.mapred.TextInputFormat'
OUTPUTFORMAT
'org.apache.hadoop.hive.ql.io.IgnoreKeyTextOutputFormat'
LOCATION
's3://stedi-house-one/step_trainer_landing'
TBLPROPERTIES (
'transient_lastDdlTime'='1779733636')