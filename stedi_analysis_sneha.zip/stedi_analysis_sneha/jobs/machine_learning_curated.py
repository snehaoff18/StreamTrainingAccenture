import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue import DynamicFrame

def sparkSqlQuery(glueContext, query, mapping, transformation_ctx) -> DynamicFrame:
    for alias, frame in mapping.items():
        frame.toDF().createOrReplaceTempView(alias)
    result = spark.sql(query)
    return DynamicFrame.fromDF(result, glueContext, transformation_ctx)
args = getResolvedOptions(sys.argv, ['JOB_NAME'])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

# Script generated for node step_trainer_trusted
step_trainer_trusted_node1779778238990 = glueContext.create_dynamic_frame.from_catalog(database="stedi-db", table_name="step_trainer_trusted", transformation_ctx="step_trainer_trusted_node1779778238990")

# Script generated for node accelerometer_trusted
accelerometer_trusted_node1779778238276 = glueContext.create_dynamic_frame.from_catalog(database="stedi-db", table_name="accelerometer_trusted", transformation_ctx="accelerometer_trusted_node1779778238276")

# Script generated for node SQL Query
SqlQuery980 = '''
SELECT
    a.user,
    a.timestamp,
    a.x,
    a.y,
    a.z,
    s.distancefromobject
FROM accelerometer_trusted a
JOIN step_trainer_trusted s
ON a.timestamp = s.sensorreadingtime
'''
SQLQuery_node1779778325548 = sparkSqlQuery(glueContext, query = SqlQuery980, mapping = {"a":accelerometer_trusted_node1779778238276, "s":step_trainer_trusted_node1779778238990}, transformation_ctx = "SQLQuery_node1779778325548")

job.commit()