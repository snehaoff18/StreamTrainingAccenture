import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from awsgluedq.transforms import EvaluateDataQuality
from awsglue import DynamicFrame

def sparkSqlQuery(glueContext, query, mapping, transformation_ctx) -> DynamicFrame:
    for alias, frame in mapping.items():
        frame.toDF().createOrReplaceTempView(alias)
    result = spark.sql(query)
    return DynamicFrame.fromDF(result, glueContext, transformation_ctx)
args = getResolvedOptions(sys.argv, ['JOB_NAME'])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

# Default ruleset used by all target nodes with data quality enabled
DEFAULT_DATA_QUALITY_RULESET = """
    Rules = [
        ColumnCount > 0
    ]
"""

# Script generated for node customer_trusted
customer_trusted_node1779734860876 = glueContext.create_dynamic_frame.from_catalog(database="stedi-db", table_name="customer_trusted", transformation_ctx="customer_trusted_node1779734860876")

# Script generated for node accelerometer_landing
accelerometer_landing_node1779734861664 = glueContext.create_dynamic_frame.from_catalog(database="stedi-db", table_name="accelerometer_landing", transformation_ctx="accelerometer_landing_node1779734861664")

# Script generated for node SQL Query
SqlQuery1017 = '''
SELECT a.*
FROM AmazonS3_node1 a
INNER JOIN AmazonS3_node2 c
ON a.user = c.email
'''
SQLQuery_node1779735011377 = sparkSqlQuery(glueContext, query = SqlQuery1017, mapping = {"AmazonS3_node1":accelerometer_landing_node1779734861664, "AmazonS3_node2":customer_trusted_node1779734860876}, transformation_ctx = "SQLQuery_node1779735011377")

# Script generated for node accelerometer_trusted
EvaluateDataQuality().process_rows(frame=SQLQuery_node1779735011377, ruleset=DEFAULT_DATA_QUALITY_RULESET, publishing_options={"dataQualityEvaluationContext": "EvaluateDataQuality_node1779733370106", "enableDataQualityResultsPublishing": True}, additional_options={"dataQualityResultsPublishing.strategy": "BEST_EFFORT", "observations.scope": "ALL"})
accelerometer_trusted_node1779735044693 = glueContext.getSink(path="s3://stedi-house-one/accelerometer_trusted/", connection_type="s3", updateBehavior="UPDATE_IN_DATABASE", partitionKeys=[], enableUpdateCatalog=True, transformation_ctx="accelerometer_trusted_node1779735044693")
accelerometer_trusted_node1779735044693.setCatalogInfo(catalogDatabase="stedi-db",catalogTableName="accelerometer_trusted")
accelerometer_trusted_node1779735044693.setFormat("glueparquet", compression="snappy")
accelerometer_trusted_node1779735044693.writeFrame(SQLQuery_node1779735011377)
job.commit()