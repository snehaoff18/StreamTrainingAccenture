import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from awsgluedq.transforms import EvaluateDataQuality
from awsglue import DynamicFrame

def sparkSqlQuery(glueContext, query, mapping, transformation_ctx) -> DynamicFrame:
    for alias, frame in mapping.items():
        frame.toDF().createOrReplaceTempView(alias)
    result = spark.sql(query)
    return DynamicFrame.fromDF(result, glueContext, transformation_ctx)
args = getResolvedOptions(sys.argv, ['JOB_NAME'])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

# Default ruleset used by all target nodes with data quality enabled
DEFAULT_DATA_QUALITY_RULESET = """
    Rules = [
        ColumnCount > 0
    ]
"""

# Script generated for node customer_trusted
customer_trusted_node1779757973753 = glueContext.create_dynamic_frame.from_catalog(database="stedi-db", table_name="customer_trusted", transformation_ctx="customer_trusted_node1779757973753")

# Script generated for node accelerometer_trusted
accelerometer_trusted_node1779757979671 = glueContext.create_dynamic_frame.from_catalog(database="stedi-db", table_name="accelerometer_trusted", transformation_ctx="accelerometer_trusted_node1779757979671")

# Script generated for node SQL Query
SqlQuery1209 = '''
SELECT DISTINCT c.*
FROM customer_trusted c
INNER JOIN accelerometer_trusted a
ON c.email = a.user
'''
SQLQuery_node1779735910175 = sparkSqlQuery(glueContext, query = SqlQuery1209, mapping = {"AmazonS3_node1":customer_trusted_node1779757973753, "AmazonS3_node2":accelerometer_trusted_node1779757979671}, transformation_ctx = "SQLQuery_node1779735910175")

# Script generated for node customer_curated
EvaluateDataQuality().process_rows(frame=SQLQuery_node1779735910175, ruleset=DEFAULT_DATA_QUALITY_RULESET, publishing_options={"dataQualityEvaluationContext": "EvaluateDataQuality_node1779733370106", "enableDataQualityResultsPublishing": True}, additional_options={"dataQualityResultsPublishing.strategy": "BEST_EFFORT", "observations.scope": "ALL"})
customer_curated_node1779735984887 = glueContext.getSink(path="s3://stedi-house-one/customers_curated/", connection_type="s3", updateBehavior="UPDATE_IN_DATABASE", partitionKeys=[], enableUpdateCatalog=True, transformation_ctx="customer_curated_node1779735984887")
customer_curated_node1779735984887.setCatalogInfo(catalogDatabase="stedi-db",catalogTableName="customer_curated")
customer_curated_node1779735984887.setFormat("glueparquet", compression="snappy")
customer_curated_node1779735984887.writeFrame(SQLQuery_node1779735910175)
job.commit()